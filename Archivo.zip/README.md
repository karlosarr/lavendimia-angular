Lavendimia
==========

Sistema La Vendimia

El sistema deberá permitir la venta de muebles a crédito y administrar el registro de clientes. Permitirá la configuración de los plazos máximos permitidos, así como la tasa de financiamiento y porcentaje de enganche.

Contará con las siguientes opciones:
--------------------

+ Catálogo de Clientes
+ Catálogo de Artículos
+ Configuración General
+ Registro de Venta

URL
--------------------
http://carlosruiz2.esy.es/