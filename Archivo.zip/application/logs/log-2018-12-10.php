<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-12-10 23:31:21 --> Config Class Initialized
INFO - 2018-12-10 23:31:21 --> Hooks Class Initialized
DEBUG - 2018-12-10 23:31:21 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:21 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:21 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:21 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:21 --> Router Class Initialized
INFO - 2018-12-10 23:31:21 --> Output Class Initialized
INFO - 2018-12-10 23:31:21 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:21 --> Input Class Initialized
INFO - 2018-12-10 23:31:21 --> Language Class Initialized
INFO - 2018-12-10 23:31:21 --> Loader Class Initialized
INFO - 2018-12-10 23:31:21 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:21 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:21 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:21 --> Database Driver Class Initialized
ERROR - 2018-12-10 23:31:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /var/www/html/lavendimia-angular/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-10 23:31:21 --> Unable to connect to the database
INFO - 2018-12-10 23:31:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-12-10 23:31:31 --> Config Class Initialized
INFO - 2018-12-10 23:31:32 --> Hooks Class Initialized
DEBUG - 2018-12-10 23:31:32 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:32 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:32 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:32 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:32 --> Router Class Initialized
INFO - 2018-12-10 23:31:32 --> Output Class Initialized
INFO - 2018-12-10 23:31:32 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:32 --> Input Class Initialized
INFO - 2018-12-10 23:31:32 --> Language Class Initialized
INFO - 2018-12-10 23:31:32 --> Loader Class Initialized
INFO - 2018-12-10 23:31:32 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:32 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:32 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:32 --> Database Driver Class Initialized
ERROR - 2018-12-10 23:31:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'user'@'dockercontainers_apache-php_1.dockercontainers_appnet' (using password: YES) /var/www/html/lavendimia-angular/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-10 23:31:32 --> Unable to connect to the database
INFO - 2018-12-10 23:31:32 --> Language file loaded: language/english/db_lang.php
INFO - 2018-12-10 23:31:33 --> Config Class Initialized
INFO - 2018-12-10 23:31:33 --> Hooks Class Initialized
DEBUG - 2018-12-10 23:31:33 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:33 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:33 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:33 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:33 --> Router Class Initialized
INFO - 2018-12-10 23:31:33 --> Output Class Initialized
INFO - 2018-12-10 23:31:33 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:33 --> Input Class Initialized
INFO - 2018-12-10 23:31:33 --> Language Class Initialized
INFO - 2018-12-10 23:31:33 --> Loader Class Initialized
INFO - 2018-12-10 23:31:33 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:33 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:33 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:33 --> Database Driver Class Initialized
ERROR - 2018-12-10 23:31:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'user'@'dockercontainers_apache-php_1.dockercontainers_appnet' (using password: YES) /var/www/html/lavendimia-angular/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-10 23:31:33 --> Unable to connect to the database
INFO - 2018-12-10 23:31:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-12-10 23:31:34 --> Config Class Initialized
INFO - 2018-12-10 23:31:34 --> Hooks Class Initialized
DEBUG - 2018-12-10 23:31:34 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:34 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:34 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:34 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:34 --> Router Class Initialized
INFO - 2018-12-10 23:31:34 --> Output Class Initialized
INFO - 2018-12-10 23:31:34 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:34 --> Input Class Initialized
INFO - 2018-12-10 23:31:34 --> Language Class Initialized
INFO - 2018-12-10 23:31:34 --> Loader Class Initialized
INFO - 2018-12-10 23:31:34 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:34 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:34 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:34 --> Database Driver Class Initialized
ERROR - 2018-12-10 23:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'user'@'dockercontainers_apache-php_1.dockercontainers_appnet' (using password: YES) /var/www/html/lavendimia-angular/system/database/drivers/mysqli/mysqli_driver.php 201
INFO - 2018-12-10 23:31:34 --> Config Class Initialized
INFO - 2018-12-10 23:31:34 --> Hooks Class Initialized
ERROR - 2018-12-10 23:31:34 --> Unable to connect to the database
DEBUG - 2018-12-10 23:31:34 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:34 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:34 --> Language file loaded: language/english/db_lang.php
INFO - 2018-12-10 23:31:34 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:34 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:34 --> Router Class Initialized
INFO - 2018-12-10 23:31:34 --> Output Class Initialized
INFO - 2018-12-10 23:31:34 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:34 --> Input Class Initialized
INFO - 2018-12-10 23:31:34 --> Language Class Initialized
INFO - 2018-12-10 23:31:34 --> Loader Class Initialized
INFO - 2018-12-10 23:31:34 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:34 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:34 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:34 --> Database Driver Class Initialized
ERROR - 2018-12-10 23:31:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'user'@'dockercontainers_apache-php_1.dockercontainers_appnet' (using password: YES) /var/www/html/lavendimia-angular/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-10 23:31:34 --> Unable to connect to the database
INFO - 2018-12-10 23:31:34 --> Language file loaded: language/english/db_lang.php
INFO - 2018-12-10 23:31:58 --> Config Class Initialized
INFO - 2018-12-10 23:31:58 --> Hooks Class Initialized
DEBUG - 2018-12-10 23:31:58 --> UTF-8 Support Enabled
INFO - 2018-12-10 23:31:58 --> Utf8 Class Initialized
INFO - 2018-12-10 23:31:58 --> URI Class Initialized
DEBUG - 2018-12-10 23:31:58 --> No URI present. Default controller set.
INFO - 2018-12-10 23:31:58 --> Router Class Initialized
INFO - 2018-12-10 23:31:58 --> Output Class Initialized
INFO - 2018-12-10 23:31:58 --> Security Class Initialized
DEBUG - 2018-12-10 23:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-12-10 23:31:58 --> Input Class Initialized
INFO - 2018-12-10 23:31:58 --> Language Class Initialized
INFO - 2018-12-10 23:31:58 --> Loader Class Initialized
INFO - 2018-12-10 23:31:58 --> Helper loaded: url_helper
INFO - 2018-12-10 23:31:58 --> Helper loaded: html_helper
INFO - 2018-12-10 23:31:58 --> Helper loaded: form_helper
INFO - 2018-12-10 23:31:58 --> Database Driver Class Initialized
INFO - 2018-12-10 23:31:58 --> Controller Class Initialized
INFO - 2018-12-10 23:31:58 --> File loaded: /var/www/html/lavendimia-angular/application/views/template/header.php
INFO - 2018-12-10 23:31:58 --> File loaded: /var/www/html/lavendimia-angular/application/views/inicio.php
INFO - 2018-12-10 23:31:58 --> File loaded: /var/www/html/lavendimia-angular/application/views/template/footer.php
INFO - 2018-12-10 23:31:58 --> Final output sent to browser
DEBUG - 2018-12-10 23:31:58 --> Total execution time: 0.2244
