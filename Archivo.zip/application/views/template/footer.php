<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
        </div>
        <!-- Metis Menu Plugin JavaScript -->
        <?= script_tag('assets/js/metisMenu/metisMenu.min.js'); ?>

        <!-- Custom Theme JavaScript -->
        <?= script_tag('assets/js/sb-admin-2.js'); ?>
    </body>
</html>